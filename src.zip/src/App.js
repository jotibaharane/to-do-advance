import "./App.css";
import React, { useState } from "react";
import WellCome from "./components/WellCome";
import TaskBoard from "./components/TaskBoard";
import Add from "./components/Add";
import { Routes, Route } from "react-router-dom";

function App(props) {
  const [data, setData] = useState([]);
  const [togal, setTogal] = useState(true);

  return (
    <div className="App">
      <TaskBoard data={data} setData={setData} setTogal={setTogal} />
      {/* <Routes>
        {data.length && (
          <Route
            path="/"
            element={
              <TaskBoard data={data} setData={setData} setTogal={setTogal} />
            }
          />
        )}
        <Route path="/" element={<WellCome />} />
        <Route
          path="/add/:id"
          element={
            <Add
              setData={setData}
              data={data}
              togal={togal}
              setTogal={setTogal}
            />
          }
        />
      </Routes> */}
    </div>
  );
}

export default App;
