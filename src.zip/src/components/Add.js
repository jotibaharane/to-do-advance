import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import SelectOpt from "./SelectOpt";
import "./Add.css";
function Add(props) {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [note, setNote] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();
  const values = () => {
    let data = "";
    if (title && date && note) {
      data = {
        id: Math.random().toString(),
        title: title,
        date: new Date(date),
        note: note,
      };
      props.setData((prevdata) => [...prevdata, data]);
      navigate("/");
    } else {
      alert("All fields are mandetory,please enter data");
    }
  };

  useEffect(() => {
    
    if (!props.togal) {
      if (id !== "id") {
        let val = props.data.find((el) => {
          return el.id === id;
        });
        setNote(val.note);
        setTitle(val.title);
        const current = new Date(val.date);
        const Udate = `${current.getFullYear()}-${
          current.getMonth() + 1 < 10
            ? "0" + (current.getMonth() + 1)
            : current.getMonth() + 1
        }-${
          current.getDate() < 10 ? "0" + current.getDate() : current.getDate()
        }`;
        setDate(Udate);
        console.log(val);
      }
    }
  }, [props.togal]);

  const update = (id) => {
    let data = "";
    if (title && date && note && !props.togal) {
      data = props.data.map((el) => {
        return el.id === id
          ? { ...el, title: title, date: new Date(date), note: note }
          : el;
      });
      props.setData(data);
      props.setTogal(true);
      navigate("/");
    } else {
      alert("All fields are mandetory,please enter data");
    }
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-25">
          <label htmlFor="Title">Title</label>
        </div>
        <div className="col-75">
          <input
            type="text"
            className="Title"
            name="Title"
            placeholder="Your Title.."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
      </div>

      <div className="row">
        <div className="col-25">
          <label htmlFor="date">Date</label>
        </div>
        <div className="col-75">
          <input
            type="date"
            className="date"
            name="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
      </div>

      <div className="row">
        <div className="col-25">
          <label htmlFor="day">Day</label>
        </div>
        <div className="col-75">
          <SelectOpt setDate={setDate} />
        </div>
      </div>

      <div className="row">
        <div className="col-25">
          <label htmlFor="Note">Note</label>
        </div>
        <div className="col-75">
          <textarea
            className="note"
            name="subject"
            placeholder="Write something.."
            value={note}
            style={{ height: "200px" }}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>
      </div>

      <div className="row">
        {props.togal ? (
          <input
            type="button"
            value="Save"
            className="btn1"
            onClick={() => {
              values();
            }}
          />
        ) : (
          <input
            type="button"
            value="Update"
            className="btn1"
            onClick={() => {
              update(id);
            }}
          />
        )}
        <input
          type="button"
          value="Cancel"
          className="btn2"
          onClick={() => navigate("/")}
        />
      </div>
    </div>
  );
}

export default Add;
