import React from "react";
import "./Date.css";
function Date(props) {
  let date = props.date.toLocaleString("en-US", { day: "2-digit" });
  let year = props.date.getFullYear();
  let month = props.date.toLocaleString("en-US", { month: "2-digit" });
  return (
    <div className="expense-date">
      <div className="expense-date_day">{date + "-"}</div>
      <div className="expense-date_month">{month + "-"}</div>
      <div className="expense-date_year">{year}</div>
    </div>
  );
}

export default Date;
