import React from "react";
import Date from "./Date";
import { useNavigate } from "react-router-dom";
import { useDrag } from "react-dnd";
function Card(props) {
  const navigate = useNavigate();
  const value = props.value;
  const deleteValue = (id) => {
    const dataM = props.data.filter((data) => data.id !== id);
    props.setData(dataM);
  };
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "card",
    item: { id: value.id },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));
  const editItem = (id) => {
    props.setTogal(false);
    navigate(`/add/${id}`);
  };

  return (
    <div className="test" ref={drag}>
      <input type="checkbox" onChange={(e) => props.fun(e, value.id)} />
      <h4>
        <Date date={value.date} />
      </h4>
      <p>{value.title}</p>
      <img
        src="edit.jpeg"
        alt="edit"
        className="edit"
        onClick={() => editItem(value.id)}
      />
      <img
        src="delete.png"
        alt="delete"
        className="delete"
        onClick={() => deleteValue(value.id)}
      />
    </div>
  );
}

export default Card;
