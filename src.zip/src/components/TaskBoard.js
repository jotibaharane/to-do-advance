import React, { useRef, useState } from "react";
import "./TaskBoard.css";
// import Card from "./Card";
import { useNavigate } from "react-router-dom";

const data = [
  { title: "group 1", items: ["1", "2", "3"] },
  { title: "group 2", items: ["4", "5"] },
];

function TaskBoard(props) {
  const [count, setCount] = useState(0);
  const [list, setList] = useState(data);
  const [dragging, setDragging] = useState(false);
  const dragItem = useRef();
  const dragNode = useRef();

  const handelDragStart = (e, params) => {
    dragItem.current = params;
    dragNode.current = e.target;
    dragNode.current.addEventListener("dragend", handleDragend);
    setTimeout(() => {
      setDragging(true);
    }, 0);
    
  };

const handleDragEnter=(e,params)=>{
if(dragNode.current!==e.target)
{
console.log("diffrent");
};
}

  const handleDragend = () => {
    setDragging(false);
    dragNode.current.removeEventListener("dragend", handleDragend);
    dragItem.current = null;
    dragNode.current = null;
  };

  const getStyles = (params) => {
    const currentItem = dragItem.current;
    if (
      currentItem.grpI === params.grpI &&
      currentItem.itemI === params.itemI
    ) {
      return "current dnd-item";
    }
    return "dnd-item";
  };

  const Navigate = useNavigate();
  const item = props.data;
  const checkbox = (d, id) => {
    console.log(d.target.checked);
    if (d.target.checked) {
      setCount(count + 1);
      const dataM = item.filter((data) => data.id !== id);
      props.setData(dataM);
    }
  };

  return (
    <div className="card">
      <div className="taskNav">
        <img src="taskLogo.png" alt="task-logo" />
        <h1>Task Board </h1>
        <input
          type="button"
          value="Add Task"
          onClick={() => Navigate("/add/id")}
        />
      </div>

      <header className="App-header">
        <div className="drag-n-drop">
          {list.map((grp, grpI) => (
            <div key={grp.title} className="dnd-group">
              {grp.items.map((item, itemI) => (
                <div
                  draggable
                  onDragStart={(e) => handelDragStart(e, { grpI, itemI })}
                  onDragEnter={dragging?(e)=>handleDragEnter(e,{ grpI, itemI }):null}
                  key={item}
                  className={dragging ? getStyles({ grpI, itemI }) : "dnd-item"}
                >
                  {item}
                </div>
              ))}
            </div>
          ))}
        </div>
      </header>

      {/* //   {item.map((index) => {
    //     return (
    //       <Card
    //         key={index.id}
    //         value={index}
    //         setData={props.setData}
    //         {...props}
    //         fun={checkbox}
    //         setTogal={props.setTogal}
    //       />
    //     );
    //   })} */}

      <div className="bottom">
        <div className="dropup">
          <button className="dropbtn count-btn">Completed({count})▲</button>
          <div className="dropup-content">
            <div
              className="count"
              style={{ display: "flex", padding: "20px" }}
              onClick={() => setCount(0)}
            >
              <p>Clear All</p>
              <img src="delete.png" alt="delet" className="count-del" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TaskBoard;
